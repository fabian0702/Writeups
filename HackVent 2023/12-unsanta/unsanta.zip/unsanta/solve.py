from test_mersenne import *
from randcrack import RandCrack

import random

with open('./backup/a.jpg', 'rb') as f:
    c1 = f.read()

with open('./memes/a.jpg', 'rb') as f:
    c2 = f.read()

cenc = b"".join([bytes([c1[i] ^ c2[i]]) for i in range(len(c1))])

from Crypto.Util.number import bytes_to_long

random.seed(bytes_to_long(b'aaaabbbb'))

a = []
#cenc = b''
#for _ in range((len(c1) + 3) // 4):
#    a.append(random.getrandbits(32))
#    cenc += a[-1].to_bytes(4, "big")

s = []
for _ in range((len(c1) + 3) // 4):
    s.append(int.from_bytes(cenc[_*4:_*4+4], 'big'))
    #assert(a[_] == s[-1])

from Crypto.Util.number import bytes_to_long, long_to_bytes
    
outputs = s[:624]
b = BreakerPy()
recovered_seeds = b.get_seeds_python(outputs, 64)
print(recovered_seeds)
print(long_to_bytes(array_to_int(recovered_seeds)))
print("success")

cracker = RandCrack()

for i in range(624):
    cracker.submit(s[i])

for i in range(624, (len(c1)//4)):
    assert(cracker.predict_getrandbits(32) in s)

print('success')

#with open('./memes/b.jpeg', 'rb') as f:
#    c3 = f.read()
#
#s = cenc[:624//4]
#for _ in range((len(c2) + 3) // 4):
#    s += cracker.predict_getrandbits(32).to_bytes(4, "big")
cenc = b"".join([bytes([cenc[i] ^ c2[i]]) for i in range(len(c2))])

print(cenc[:10], c1[:10])

with open('out1.jpeg', "wb+") as fp:
    fp.write(cenc)